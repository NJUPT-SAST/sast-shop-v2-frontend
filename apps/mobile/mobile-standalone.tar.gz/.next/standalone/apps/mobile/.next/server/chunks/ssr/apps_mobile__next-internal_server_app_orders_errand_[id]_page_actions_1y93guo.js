module.exports=[75327,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_orders_errand_%5Bid%5D_page_actions_1y93guo.js.map
module.exports=[13192,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_icon_svg_route_actions_0jsbzm0.js.map
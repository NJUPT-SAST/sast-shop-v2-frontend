module.exports=[24030,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_orders_page_actions_0y3dnow.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/product-image/route.js")
R.c("server/chunks/[root-of-the-server]__1wfgtu8._.js")
R.c("server/chunks/_1p5p7ba._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/1om2__next-internal_server_app_api_uploads_product-image_route_actions_1liiaha.js")
R.m(80713)
module.exports=R.m(80713).exports

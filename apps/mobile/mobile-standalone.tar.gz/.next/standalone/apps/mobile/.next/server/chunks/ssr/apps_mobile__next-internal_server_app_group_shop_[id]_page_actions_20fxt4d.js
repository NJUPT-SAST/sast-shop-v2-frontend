module.exports=[18193,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_group_shop_%5Bid%5D_page_actions_20fxt4d.js.map
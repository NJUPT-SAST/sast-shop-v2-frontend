var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/connect/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1iy6q8c._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/_1p5p7ba._.js")
R.c("server/chunks/044u_mobile__next-internal_server_app_api_connect_[___path]_route_actions_1pqlqn9.js")
R.m(81672)
module.exports=R.m(81672).exports

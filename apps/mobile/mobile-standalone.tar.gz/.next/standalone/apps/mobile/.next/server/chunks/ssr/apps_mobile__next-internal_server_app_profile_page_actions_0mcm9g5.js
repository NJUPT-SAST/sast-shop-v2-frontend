module.exports=[84165,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_profile_page_actions_0mcm9g5.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/live/route.js")
R.c("server/chunks/[root-of-the-server]__1q038ry._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/apps_mobile__next-internal_server_app_api_health_live_route_actions_027t_u3.js")
R.m(12108)
module.exports=R.m(12108).exports

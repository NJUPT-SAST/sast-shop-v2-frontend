module.exports=[50188,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_group_templates_page_actions_1wy62q0.js.map
module.exports=[69451,s=>{"use strict";s.s([])}];

//# sourceMappingURL=1om2__next-internal_server_app_api_uploads_product-image_route_actions_1liiaha.js.map
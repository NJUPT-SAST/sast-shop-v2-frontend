module.exports=[47296,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_shop_page_actions_1guxwce.js.map
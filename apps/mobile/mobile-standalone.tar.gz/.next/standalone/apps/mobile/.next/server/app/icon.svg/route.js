var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__0rbuyab._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/apps_mobile__next-internal_server_app_icon_svg_route_actions_0jsbzm0.js")
R.m(5591)
module.exports=R.m(5591).exports

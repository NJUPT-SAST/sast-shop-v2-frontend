1:"$Sreact.fragment"
3:I[26138,["/_next/static/chunks/1-zn5i7kjc2e4.js","/_next/static/chunks/368aru7zsdc1b.js","/_next/static/chunks/03ctf_1vcv6e3.js","/_next/static/chunks/1e33x3imciu94.js","/_next/static/chunks/3j_ccaelt2i-v.js","/_next/static/chunks/2ki2l_rpnsmal.js","/_next/static/chunks/2ma6sbibc0knr.js","/_next/static/chunks/1cee345dl3r7f.js","/_next/static/chunks/099dj2hp6u5i1.js","/_next/static/chunks/0fuue4hd33g8r.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"d4ctecWSDewWHL9WWxWGT"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/shop;307;"}

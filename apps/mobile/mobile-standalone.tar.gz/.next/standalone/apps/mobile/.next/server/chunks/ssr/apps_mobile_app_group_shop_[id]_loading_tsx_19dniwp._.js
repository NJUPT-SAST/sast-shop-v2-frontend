module.exports=[35348,a=>{"use strict";var b=a.i(25847),c=a.i(86558);a.s(["default",0,function(){return(0,b.jsx)(c.MobilePageSkeleton,{})}])},73647,a=>{a.n(a.i(35348))}];

//# sourceMappingURL=apps_mobile_app_group_shop_%5Bid%5D_loading_tsx_19dniwp._.js.map
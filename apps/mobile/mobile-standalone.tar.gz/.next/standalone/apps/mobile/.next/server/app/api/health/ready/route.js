var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/ready/route.js")
R.c("server/chunks/[root-of-the-server]__1vbszpf._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/apps_mobile__next-internal_server_app_api_health_ready_route_actions_1dmx48j.js")
R.m(81123)
module.exports=R.m(81123).exports

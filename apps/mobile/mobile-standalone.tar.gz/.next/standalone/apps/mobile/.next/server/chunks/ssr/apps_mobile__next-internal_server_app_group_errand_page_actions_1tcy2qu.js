module.exports=[62025,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_group_errand_page_actions_1tcy2qu.js.map
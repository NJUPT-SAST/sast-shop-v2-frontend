var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/session/route.js")
R.c("server/chunks/[root-of-the-server]__1yxwue6._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/_1etoyyv._.js")
R.c("server/chunks/packages_api_src_index_ts_15wze-z._.js")
R.c("server/chunks/apps_mobile__next-internal_server_app_api_auth_session_route_actions_01v60gr.js")
R.m(73491)
module.exports=R.m(73491).exports

module.exports=[68617,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_api_health_ready_route_actions_1dmx48j.js.map
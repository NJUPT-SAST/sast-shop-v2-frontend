globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/d4ctecWSDewWHL9WWxWGT/_buildManifest.js",
    "static/d4ctecWSDewWHL9WWxWGT/_ssgManifest.js",
    "static/d4ctecWSDewWHL9WWxWGT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0707p-tetnbzs.js",
    "static/chunks/1alpkum12l2rc.js",
    "static/chunks/0g2uqk1_y08l4.js",
    "static/chunks/25s90u9n7cy_n.js",
    "static/chunks/0ygc4gdmkgzp5.js",
    "static/chunks/turbopack-1tr0p0r8i4g9w.js"
  ]
};

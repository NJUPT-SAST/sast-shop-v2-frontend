module.exports=[73451,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_orders_spot_%5Bid%5D_page_actions_1ggpolg.js.map
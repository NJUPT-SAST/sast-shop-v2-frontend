module.exports=[38769,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_group_purchase_%5Bid%5D_page_actions_0d04xep.js.map
module.exports=[42737,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_mobile__next-internal_server_app_api_connect_%5B___path%5D_route_actions_1pqlqn9.js.map
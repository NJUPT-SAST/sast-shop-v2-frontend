module.exports=[71353,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_api_health_live_route_actions_027t_u3.js.map
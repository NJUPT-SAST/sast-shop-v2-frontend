module.exports=[9124,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app__not-found_page_actions_0guq66c.js.map
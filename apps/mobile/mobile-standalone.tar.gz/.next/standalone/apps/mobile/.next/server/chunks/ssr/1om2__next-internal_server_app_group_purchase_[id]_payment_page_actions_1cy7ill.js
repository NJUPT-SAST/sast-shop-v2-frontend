module.exports=[35878,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1om2__next-internal_server_app_group_purchase_%5Bid%5D_payment_page_actions_1cy7ill.js.map
module.exports=[43971,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app_group_page_actions_0kw2m9u.js.map
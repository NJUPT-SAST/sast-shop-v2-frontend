module.exports=[83720,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_mobile__next-internal_server_app__global-error_page_actions_14qzo2e.js.map
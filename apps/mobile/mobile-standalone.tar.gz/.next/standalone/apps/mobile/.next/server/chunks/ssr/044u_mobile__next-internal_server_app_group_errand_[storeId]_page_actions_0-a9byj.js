module.exports=[87900,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_mobile__next-internal_server_app_group_errand_%5BstoreId%5D_page_actions_0-a9byj.js.map
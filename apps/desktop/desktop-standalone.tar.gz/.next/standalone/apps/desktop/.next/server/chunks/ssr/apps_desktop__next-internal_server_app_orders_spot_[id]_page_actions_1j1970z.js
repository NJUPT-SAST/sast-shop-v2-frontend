module.exports=[3657,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_orders_spot_%5Bid%5D_page_actions_1j1970z.js.map
module.exports=[60909,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_orders_errand_%5Bid%5D_page_actions_15s2v7d.js.map
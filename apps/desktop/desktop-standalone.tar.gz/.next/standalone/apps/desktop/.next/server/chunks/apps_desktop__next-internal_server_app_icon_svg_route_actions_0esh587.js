module.exports=[42762,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_icon_svg_route_actions_0esh587.js.map
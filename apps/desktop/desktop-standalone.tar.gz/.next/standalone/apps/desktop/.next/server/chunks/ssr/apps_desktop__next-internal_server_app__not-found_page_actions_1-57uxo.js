module.exports=[69109,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app__not-found_page_actions_1-57uxo.js.map
module.exports=[7860,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_orders_page_actions_01vm6ta.js.map
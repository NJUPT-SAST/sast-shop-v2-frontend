module.exports=[44793,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_profile_page_actions_1-t45yr.js.map
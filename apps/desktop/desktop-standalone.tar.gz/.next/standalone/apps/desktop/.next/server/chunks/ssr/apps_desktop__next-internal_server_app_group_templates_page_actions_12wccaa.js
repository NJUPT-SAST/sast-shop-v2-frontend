module.exports=[58933,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_group_templates_page_actions_12wccaa.js.map
var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__1xzumwx._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/packages_api_src_index_ts_15wze-z._.js")
R.c("server/chunks/_1_6t-p2._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/apps_desktop__next-internal_server_app_auth_callback_route_actions_0u7gjdf.js")
R.m(47380)
module.exports=R.m(47380).exports

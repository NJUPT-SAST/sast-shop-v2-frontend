module.exports=[44763,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_api_auth_session_route_actions_1yy_md8.js.map
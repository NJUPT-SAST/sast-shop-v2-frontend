globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/xdVvu9j4E0DKldMbhR4df/_buildManifest.js",
    "static/xdVvu9j4E0DKldMbhR4df/_ssgManifest.js",
    "static/xdVvu9j4E0DKldMbhR4df/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0707p-tetnbzs.js",
    "static/chunks/0h_g4s-wi_2ti.js",
    "static/chunks/0g2uqk1_y08l4.js",
    "static/chunks/25s90u9n7cy_n.js",
    "static/chunks/0ygc4gdmkgzp5.js",
    "static/chunks/turbopack-2jto0ibk8jj93.js"
  ]
};

module.exports=[35628,s=>{"use strict";s.s([])}];

//# sourceMappingURL=0ssi__next-internal_server_app_api_uploads_product-image_route_actions_1l3pprp.js.map
var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/lark/authorize/route.js")
R.c("server/chunks/[root-of-the-server]__1boe2_p._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/044u_desktop__next-internal_server_app_api_auth_lark_authorize_route_actions_1htvobg.js")
R.m(58472)
module.exports=R.m(58472).exports

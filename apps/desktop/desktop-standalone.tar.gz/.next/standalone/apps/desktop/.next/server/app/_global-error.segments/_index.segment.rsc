1:"$Sreact.fragment"
2:I[5433,["/_next/static/chunks/0bncdo7ale4v1.js","/_next/static/chunks/1e33x3imciu94.js"],"default"]
3:I[72328,["/_next/static/chunks/0bncdo7ale4v1.js","/_next/static/chunks/1e33x3imciu94.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"xdVvu9j4E0DKldMbhR4df"}

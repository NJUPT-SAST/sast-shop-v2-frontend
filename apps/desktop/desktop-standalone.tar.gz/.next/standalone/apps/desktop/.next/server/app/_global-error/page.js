var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0-_wwz2._.js")
R.c("server/chunks/ssr/13-7_next_dist_esm_build_templates_app-page_09gwcs8.js")
R.c("server/chunks/ssr/[root-of-the-server]__0s47dq6._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1zf4gwj._.js")
R.c("server/chunks/ssr/13-7_next_dist_client_components_builtin_global-error_1z03vgi.js")
R.c("server/chunks/ssr/apps_desktop__next-internal_server_app__global-error_page_actions_0x4y2nm.js")
R.m(94164)
module.exports=R.m(94164).exports

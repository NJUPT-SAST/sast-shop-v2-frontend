module.exports=[7717,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app__global-error_page_actions_0x4y2nm.js.map
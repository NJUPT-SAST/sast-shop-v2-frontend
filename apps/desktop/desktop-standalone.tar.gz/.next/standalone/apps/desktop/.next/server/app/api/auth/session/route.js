var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/session/route.js")
R.c("server/chunks/[root-of-the-server]__1bivvq7._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/_1_xxmzn._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/packages_api_src_index_ts_15wze-z._.js")
R.c("server/chunks/apps_desktop__next-internal_server_app_api_auth_session_route_actions_1yy_md8.js")
R.m(29485)
module.exports=R.m(29485).exports

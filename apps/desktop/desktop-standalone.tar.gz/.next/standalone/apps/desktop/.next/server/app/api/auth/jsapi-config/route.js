var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/jsapi-config/route.js")
R.c("server/chunks/[root-of-the-server]__04tuz5g._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/_1nmtj0a._.js")
R.c("server/chunks/packages_api_src_index_ts_15wze-z._.js")
R.c("server/chunks/044u_desktop__next-internal_server_app_api_auth_jsapi-config_route_actions_1yhj7df.js")
R.m(78632)
module.exports=R.m(78632).exports

1:"$Sreact.fragment"
2:I[45093,["/_next/static/chunks/1vi2qrbniym7q.js","/_next/static/chunks/0k4r5q8ksn_l3.js","/_next/static/chunks/1g6ok5rg5o4q6.js","/_next/static/chunks/2r6i7dcbzh8ud.js","/_next/static/chunks/1e33x3imciu94.js","/_next/static/chunks/0275zmd3nrvu1.js","/_next/static/chunks/0zaqtswwyc4qp.js"],"PublishSpotForm"]
3:I[26138,["/_next/static/chunks/1vi2qrbniym7q.js","/_next/static/chunks/0k4r5q8ksn_l3.js","/_next/static/chunks/1g6ok5rg5o4q6.js","/_next/static/chunks/2r6i7dcbzh8ud.js","/_next/static/chunks/1e33x3imciu94.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"dataSource":"local","connectBaseUrl":"http://localhost:3002/api/connect"}],[["$","script","script-0",{"src":"/_next/static/chunks/0275zmd3nrvu1.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0zaqtswwyc4qp.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"xdVvu9j4E0DKldMbhR4df"}
5:null

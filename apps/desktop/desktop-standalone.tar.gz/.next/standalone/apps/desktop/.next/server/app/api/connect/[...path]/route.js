var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/connect/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__19e9jby._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/_073a8ki._.js")
R.c("server/chunks/044u_desktop__next-internal_server_app_api_connect_[___path]_route_actions_0q9quod.js")
R.m(29998)
module.exports=R.m(29998).exports

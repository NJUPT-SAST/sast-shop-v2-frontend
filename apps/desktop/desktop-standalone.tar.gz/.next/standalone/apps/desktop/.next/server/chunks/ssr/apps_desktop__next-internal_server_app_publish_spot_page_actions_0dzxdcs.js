module.exports=[70178,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_publish_spot_page_actions_0dzxdcs.js.map
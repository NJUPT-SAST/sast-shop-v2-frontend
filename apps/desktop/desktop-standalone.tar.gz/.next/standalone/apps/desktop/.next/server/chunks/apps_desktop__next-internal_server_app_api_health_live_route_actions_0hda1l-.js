module.exports=[33306,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_api_health_live_route_actions_0hda1l-.js.map
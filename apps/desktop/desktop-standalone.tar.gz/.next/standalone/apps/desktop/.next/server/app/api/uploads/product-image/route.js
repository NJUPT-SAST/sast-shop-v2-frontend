var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/product-image/route.js")
R.c("server/chunks/[root-of-the-server]__18s9_sg._.js")
R.c("server/chunks/_073a8ki._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/0ssi__next-internal_server_app_api_uploads_product-image_route_actions_1l3pprp.js")
R.m(63051)
module.exports=R.m(63051).exports

module.exports=[68865,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_shop_page_actions_0l9idlg.js.map
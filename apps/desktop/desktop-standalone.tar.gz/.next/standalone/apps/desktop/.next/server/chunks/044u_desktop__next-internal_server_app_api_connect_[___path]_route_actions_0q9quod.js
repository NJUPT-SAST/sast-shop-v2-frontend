module.exports=[70453,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_desktop__next-internal_server_app_api_connect_%5B___path%5D_route_actions_0q9quod.js.map
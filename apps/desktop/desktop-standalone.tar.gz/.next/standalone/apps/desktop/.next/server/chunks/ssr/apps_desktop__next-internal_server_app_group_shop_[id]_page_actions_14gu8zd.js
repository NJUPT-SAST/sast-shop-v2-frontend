module.exports=[83869,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_group_shop_%5Bid%5D_page_actions_14gu8zd.js.map
1:"$Sreact.fragment"
3:I[26138,["/_next/static/chunks/1vi2qrbniym7q.js","/_next/static/chunks/0k4r5q8ksn_l3.js","/_next/static/chunks/1g6ok5rg5o4q6.js","/_next/static/chunks/2r6i7dcbzh8ud.js","/_next/static/chunks/1e33x3imciu94.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"xdVvu9j4E0DKldMbhR4df"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/shop;307;"}

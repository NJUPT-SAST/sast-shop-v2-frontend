module.exports=[63777,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_group_purchase_%5Bid%5D_page_actions_0v7d1cm.js.map
module.exports=[29495,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_api_health_ready_route_actions_20hnt8d.js.map
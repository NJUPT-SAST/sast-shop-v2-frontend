module.exports=[4690,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_page_actions_1h_zgii.js.map
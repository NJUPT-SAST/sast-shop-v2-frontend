var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/live/route.js")
R.c("server/chunks/[root-of-the-server]__02ppnkc._.js")
R.c("server/chunks/[root-of-the-server]__1k-ze36._.js")
R.c("server/chunks/13-7_next_0t5b1gp._.js")
R.c("server/chunks/apps_desktop__next-internal_server_app_api_health_live_route_actions_0hda1l-.js")
R.m(31840)
module.exports=R.m(31840).exports

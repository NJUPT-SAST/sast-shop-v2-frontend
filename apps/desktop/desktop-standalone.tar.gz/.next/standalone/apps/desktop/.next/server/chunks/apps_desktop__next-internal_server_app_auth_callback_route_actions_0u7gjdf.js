module.exports=[18332,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_desktop__next-internal_server_app_auth_callback_route_actions_0u7gjdf.js.map
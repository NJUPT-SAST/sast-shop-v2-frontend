1:"$Sreact.fragment"
2:I[26138,["/_next/static/chunks/0bncdo7ale4v1.js","/_next/static/chunks/1e33x3imciu94.js"],"ViewportBoundary"]
3:I[26138,["/_next/static/chunks/0bncdo7ale4v1.js","/_next/static/chunks/1e33x3imciu94.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"xdVvu9j4E0DKldMbhR4df"}

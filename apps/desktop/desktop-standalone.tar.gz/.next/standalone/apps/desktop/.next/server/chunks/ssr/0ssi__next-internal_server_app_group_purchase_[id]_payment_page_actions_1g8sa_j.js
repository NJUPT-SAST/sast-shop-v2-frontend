module.exports=[87374,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0ssi__next-internal_server_app_group_purchase_%5Bid%5D_payment_page_actions_1g8sa_j.js.map